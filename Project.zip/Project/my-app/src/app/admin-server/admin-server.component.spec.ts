import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminServerComponent } from './admin-server.component';

describe('AdminServerComponent', () => {
  let component: AdminServerComponent;
  let fixture: ComponentFixture<AdminServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminServerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
